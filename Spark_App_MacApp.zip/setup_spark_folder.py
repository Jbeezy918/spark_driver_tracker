import os

# Folder path
folder_path = os.path.expanduser("~/Desktop/spark_driver_tracker")
os.makedirs(folder_path, exist_ok=True)

# Streamlit app content
app_code = '''\
import streamlit as st
import datetime
import pyttsx3

def speak(text):
    try:
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
    except Exception as e:
        st.warning(f"Voice error: {e}")

def get_bot_response(user_input):
    if "commands" in user_input.lower():
        return "I can chat, answer questions, list commands, and be your favorite sidekick 😉"
    return f"You said: {user_input}"

def log_conversation(user_input, response):
    with open("chat_log.txt", "a") as log:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log.write(f"[{timestamp}] You: {user_input}\\n")
        log.write(f"[{timestamp}] Spark: {response}\\n\\n")

st.set_page_config(page_title="Spark Driver Tracker", layout="centered")
st.title("🚗 Spark Driver Tracker")
st.markdown("Talk to Spark below 👇")

with st.form("chat_form", clear_on_submit=True):
    user_input = st.text_input("You:", "")
    voice_toggle = st.checkbox("Voice Output", value=True)
    submitted = st.form_submit_button("Send")

if submitted and user_input:
    response = get_bot_response(user_input)
    st.markdown(f"**You:** {user_input}")
    st.markdown(f"**Spark:** {response}")
    log_conversation(user_input, response)

    if voice_toggle:
        speak(response)
'''

# Requirements content
requirements = "streamlit\npyttsx3"

# Write both files
with open(os.path.join(folder_path, "spark_streamlit_app.py"), "w") as f:
    f.write(app_code)

with open(os.path.join(folder_path, "requirements.txt"), "w") as f:
    f.write(requirements)

print("✅ Spark folder and files created on Desktop.")