import tkinter as tk
from tkinter import scrolledtext

# Basic Spark "brain" placeholder (replace with real logic later)
def get_bot_response(user_input):
    if "commands" in user_input.lower():
        return "Here's what I can do: Tell jokes, answer questions, toggle voice, be your favorite assistant 😉"
    return f"You said: {user_input}"

class SparkGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Spark - Your AI Buddy")

        # Voice toggle
        self.voice_enabled = tk.BooleanVar()
        self.voice_toggle = tk.Checkbutton(root, text="Voice Output", variable=self.voice_enabled)
        self.voice_toggle.pack(pady=5)

        # Conversation display
        self.chat_display = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=50, height=15, state='disabled')
        self.chat_display.pack(padx=10, pady=5)

        # User input
        self.entry = tk.Entry(root, width=40)
        self.entry.pack(padx=10, pady=5)
        self.entry.bind("<Return>", self.send_message)

        # Send button
        self.send_button = tk.Button(root, text="Send", command=self.send_message)
        self.send_button.pack(pady=5)

    def send_message(self, event=None):
        user_input = self.entry.get().strip()
        if not user_input:
            return

        self.display_message(f"You: {user_input}")
        self.entry.delete(0, tk.END)

        response = get_bot_response(user_input)
        self.display_message(f"Spark: {response}")

        # Optional: play voice response
        if self.voice_enabled.get():
            self.speak(response)

    def speak(self, text):
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.say(text)
            engine.runAndWait()
        except:
            self.display_message("Spark: (Voice error — pyttsx3 not installed)")

    def display_message(self, msg):
        self.chat_display.configure(state='normal')
        self.chat_display.insert(tk.END, msg + "\n")
        self.chat_display.configure(state='disabled')
        self.chat_display.see(tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = SparkGUI(root)
    root.mainloop()ßs