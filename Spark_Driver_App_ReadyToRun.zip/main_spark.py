import tkinter as tk

def run_app():
    root = tk.Tk()
    root.title("Spark Driver Tracker")
    root.geometry("500x300")
    root.configure(bg="#1E40AF")  # Walmart Blue

    label = tk.Label(root, text="🛒 Spark Driver Tracker", bg="#1E40AF", fg="white", font=("Arial", 18))
    label.pack(pady=30)

    info = tk.Label(root, text="Track earnings, trips, and mileage effortlessly!", bg="#1E40AF", fg="#FACC15", font=("Arial", 12))
    info.pack()

    root.mainloop()

if __name__ == "__main__":
    run_app()
