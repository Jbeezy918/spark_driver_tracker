import tkinter as tk
from tkinter import messagebox

class SparkApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🛒 Spark Driver Tracker")
        self.root.geometry("550x400")
        self.root.configure(bg="#1E40AF")  # Walmart Blue

        self.trips = []
        self.total_miles = 0.0
        self.total_earnings = 0.0
        self.total_fuel_cost = 0.0

        self.setup_ui()

    def setup_ui(self):
        tk.Label(self.root, text="Trip Distance (miles):", bg="#1E40AF", fg="white").pack(pady=5)
        self.miles_entry = tk.Entry(self.root)
        self.miles_entry.pack()

        tk.Label(self.root, text="Earnings ($):", bg="#1E40AF", fg="white").pack(pady=5)
        self.earnings_entry = tk.Entry(self.root)
        self.earnings_entry.pack()

        tk.Label(self.root, text="Fuel Cost ($):", bg="#1E40AF", fg="white").pack(pady=5)
        self.fuel_entry = tk.Entry(self.root)
        self.fuel_entry.pack()

        tk.Button(self.root, text="Add Trip", bg="#FACC15", command=self.add_trip).pack(pady=10)

        self.summary_label = tk.Label(self.root, text="", bg="#1E40AF", fg="white", font=("Arial", 12), justify="left")
        self.summary_label.pack(pady=10)

        self.update_summary()

    def add_trip(self):
        try:
            miles = float(self.miles_entry.get())
            earnings = float(self.earnings_entry.get())
            fuel = float(self.fuel_entry.get())
        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid numbers.")
            return

        self.trips.append((miles, earnings, fuel))
        self.total_miles += miles
        self.total_earnings += earnings
        self.total_fuel_cost += fuel

        self.miles_entry.delete(0, tk.END)
        self.earnings_entry.delete(0, tk.END)
        self.fuel_entry.delete(0, tk.END)

        self.update_summary()

    def update_summary(self):
        profit = self.total_earnings - self.total_fuel_cost
        avg_mpg = (self.total_miles / self.total_fuel_cost) if self.total_fuel_cost > 0 else 0
        text = f"Total Trips: {len(self.trips)}\nTotal Miles: {self.total_miles:.2f}\nTotal Earnings: ${self.total_earnings:.2f}\nTotal Fuel Cost: ${self.total_fuel_cost:.2f}\nProfit: ${profit:.2f}\nAverage MPG: {avg_mpg:.2f}"
        self.summary_label.config(text=text)

if __name__ == "__main__":
    root = tk.Tk()
    app = SparkApp(root)
    root.mainloop()
